// Package field implements a bloblang interpolation function templating syntax
// used in some dynamic fields within Benthos. Only the query (right-hand side)
// part of the bloblang spec is supported within interpolation functions.
package field
