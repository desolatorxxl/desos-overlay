// Package docs provides useful functions for creating documentation from
// Benthos components
package docs
