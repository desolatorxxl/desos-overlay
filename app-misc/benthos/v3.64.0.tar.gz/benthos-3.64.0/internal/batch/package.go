// Package batch contains internal utilities for interacting with message
// batches.
package batch
