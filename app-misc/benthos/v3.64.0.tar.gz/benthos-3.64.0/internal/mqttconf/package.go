// Package mqtt contains supporting utils shared between MQTT reader and writer.
package mqttconf
