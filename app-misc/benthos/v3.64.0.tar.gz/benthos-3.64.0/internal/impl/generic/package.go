// Package generic contains component implementations that do not require
// external dependencies.
package generic
