// Package interop provides utilities for initializing Benthos components that
// default to the old APIs, but when the provided manager supports it the new
// APIs are used.
//
// TODO: V4 Remove this package
package interop
