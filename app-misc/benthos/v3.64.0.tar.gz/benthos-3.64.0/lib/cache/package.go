// Package cache implements the types.Cache interface for storing and retrieving
// key/value pairs from a range of storage strategies.
package cache
