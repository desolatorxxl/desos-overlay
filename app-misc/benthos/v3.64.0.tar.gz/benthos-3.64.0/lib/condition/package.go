// Package condition contains logical operators that, based on their
// configuration, return boolean values from messages under certain
// circumstances.
package condition
