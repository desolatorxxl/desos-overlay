package condition

import (
	"encoding/json"
	"fmt"

	"github.com/Jeffail/benthos/v3/internal/docs"
	"github.com/Jeffail/benthos/v3/lib/log"
	"github.com/Jeffail/benthos/v3/lib/metrics"
	"github.com/Jeffail/benthos/v3/lib/types"
	jmespath "github.com/jmespath/go-jmespath"
)

//------------------------------------------------------------------------------

func init() {
	Constructors[TypeJMESPath] = TypeSpec{
		constructor: NewJMESPath,
		Summary: `
Executes a JMESPath query on JSON payloads, expecting a boolean result. If the
result of the query is true then the condition passes, otherwise it does not.`,
		Description: `
Please refer to the [JMESPath website](http://jmespath.org/) for information and
tutorials regarding the syntax of expressions.`,
		FieldSpecs: docs.FieldSpecs{
			docs.FieldCommon(
				"query", "A [JMESPath](http://jmespath.org/) query.",
				"foo == 'bar'", "length(doc.urls) > `0`",
			),
			partFieldSpec,
		},
		Footnotes: `
## Examples

With the following config:

` + "``` yaml" + `
jmespath:
  query: a == 'foo'
` + "```" + `

If the initial jmespaths of part 0 were:

` + "``` json" + `
{
	"a": "foo"
}
` + "```" + `

Then the condition would pass.

JMESPath is traditionally used for mutating JSON, in order to do this please
instead use the ` + "[`jmespath`](/docs/components/processors/jmespath)" + `
processor.`,
	}
}

//------------------------------------------------------------------------------

// JMESPathConfig is a configuration struct containing fields for the jmespath
// condition.
type JMESPathConfig struct {
	Part  int    `json:"part" yaml:"part"`
	Query string `json:"query" yaml:"query"`
}

// NewJMESPathConfig returns a JMESPathConfig with default values.
func NewJMESPathConfig() JMESPathConfig {
	return JMESPathConfig{
		Part:  0,
		Query: "",
	}
}

//------------------------------------------------------------------------------

// JMESPath is a condition that checks message against a jmespath query.
type JMESPath struct {
	stats metrics.Type
	log   log.Modular
	part  int
	query *jmespath.JMESPath

	mCount    metrics.StatCounter
	mTrue     metrics.StatCounter
	mFalse    metrics.StatCounter
	mErrJSONP metrics.StatCounter
	mErrJMES  metrics.StatCounter
	mErr      metrics.StatCounter
}

// NewJMESPath returns a JMESPath condition.
func NewJMESPath(
	conf Config, mgr types.Manager, log log.Modular, stats metrics.Type,
) (Type, error) {
	query, err := jmespath.Compile(conf.JMESPath.Query)
	if err != nil {
		return nil, fmt.Errorf("failed to compile JMESPath query: %v", err)
	}

	return &JMESPath{
		stats: stats,
		log:   log,
		part:  conf.JMESPath.Part,
		query: query,

		mCount:    stats.GetCounter("count"),
		mTrue:     stats.GetCounter("true"),
		mFalse:    stats.GetCounter("false"),
		mErrJSONP: stats.GetCounter("error_json_parse"),
		mErrJMES:  stats.GetCounter("error_jmespath_search"),
		mErr:      stats.GetCounter("error"),
	}, nil
}

//------------------------------------------------------------------------------

func safeSearch(part interface{}, j *jmespath.JMESPath) (res interface{}, err error) {
	defer func() {
		if r := recover(); r != nil {
			err = fmt.Errorf("jmespath panic: %v", r)
		}
	}()
	return j.Search(part)
}

// JMESPath doesn't like json.Number so we walk the tree and replace them.
func clearNumbers(v interface{}) (interface{}, bool) {
	switch t := v.(type) {
	case map[string]interface{}:
		for k, v := range t {
			if nv, ok := clearNumbers(v); ok {
				t[k] = nv
			}
		}
	case []interface{}:
		for i, v := range t {
			if nv, ok := clearNumbers(v); ok {
				t[i] = nv
			}
		}
	case json.Number:
		f, err := t.Float64()
		if err != nil {
			if i, err := t.Int64(); err == nil {
				return i, true
			}
		}
		return f, true
	}
	return nil, false
}

// Check attempts to check a message part against a configured condition.
func (c *JMESPath) Check(msg types.Message) bool {
	c.mCount.Incr(1)
	index := c.part
	if index < 0 {
		index = msg.Len() + index
	}

	if index < 0 || index >= msg.Len() {
		c.mFalse.Incr(1)
		return false
	}

	jsonPart, err := msg.Get(index).JSON()
	if err != nil {
		c.log.Debugf("Failed to parse part into json: %v\n", err)
		c.mErrJSONP.Incr(1)
		c.mErr.Incr(1)
		c.mFalse.Incr(1)
		return false
	}
	if v, replace := clearNumbers(jsonPart); replace {
		jsonPart = v
	}

	var result interface{}
	if result, err = safeSearch(jsonPart, c.query); err != nil {
		c.log.Debugf("Failed to search json: %v\n", err)
		c.mErrJMES.Incr(1)
		c.mErr.Incr(1)
		c.mFalse.Incr(1)
		return false
	}

	resultBool, _ := result.(bool)
	if resultBool {
		c.mTrue.Incr(1)
	} else {
		c.mFalse.Incr(1)
	}
	return resultBool
}

//------------------------------------------------------------------------------
