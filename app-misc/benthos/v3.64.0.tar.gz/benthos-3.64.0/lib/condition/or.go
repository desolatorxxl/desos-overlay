package condition

import (
	"fmt"

	"github.com/Jeffail/benthos/v3/lib/log"
	"github.com/Jeffail/benthos/v3/lib/metrics"
	"github.com/Jeffail/benthos/v3/lib/types"
)

//------------------------------------------------------------------------------

func init() {
	Constructors[TypeOr] = TypeSpec{
		constructor: NewOr,
		Summary: `
Returns the logical OR of children conditions.`,
		Footnotes: `
## Examples

The following snippet resolves to true if a message contains 'foo' or 'bar':

` + "``` yaml" + `
or:
  - text:
      operator: contains
      arg: foo
  - text:
      operator: contains
      arg: bar
` + "```" + ``,
	}
}

//------------------------------------------------------------------------------

// OrConfig is a configuration struct containing fields for the Or condition.
type OrConfig []Config

// NewOrConfig returns a OrConfig with default values.
func NewOrConfig() OrConfig {
	return OrConfig{}
}

//------------------------------------------------------------------------------

// Or is a condition that returns the logical or of all children.
type Or struct {
	children []Type

	mCount metrics.StatCounter
	mTrue  metrics.StatCounter
	mFalse metrics.StatCounter
}

// NewOr returns an Or condition.
func NewOr(
	conf Config, mgr types.Manager, log log.Modular, stats metrics.Type,
) (Type, error) {
	children := []Type{}
	for i, childConf := range conf.Or {
		ns := fmt.Sprintf("%v", i)
		child, err := New(childConf, mgr, log.NewModule("."+ns), metrics.Namespaced(stats, ns))
		if err != nil {
			return nil, fmt.Errorf("failed to create child '%v': %v", childConf.Type, err)
		}
		children = append(children, child)
	}
	return &Or{
		children: children,

		mCount: stats.GetCounter("count"),
		mTrue:  stats.GetCounter("true"),
		mFalse: stats.GetCounter("false"),
	}, nil
}

//------------------------------------------------------------------------------

// Check attempts to check a message part against a configured condition.
func (c *Or) Check(msg types.Message) bool {
	c.mCount.Incr(1)
	for _, child := range c.children {
		if child.Check(msg) {
			c.mTrue.Incr(1)
			return true
		}
	}
	c.mFalse.Incr(1)
	return false
}

//------------------------------------------------------------------------------
