// Package single contains implementations of various buffer types where the
// buffer can only be consumed by a single thread (but any number of writers).
package single
