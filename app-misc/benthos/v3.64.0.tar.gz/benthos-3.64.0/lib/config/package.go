// Package config defines the full configuration structure used by the Benthos
// service, including methods of normalising and linting user configuration.
package config
