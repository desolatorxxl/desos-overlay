// Package broker implements types used for routing inputs to outputs in
// non-trivial arrangements, such as fan-out or fan-in models.
package broker
